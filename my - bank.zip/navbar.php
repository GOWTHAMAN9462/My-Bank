<!-- navbar --> 
      <nav class="navbar navbar-expand-md navbar-light bg-light" style="padding-top: 0 ; padding-bottom:0">
      <a class="navbar-brand" href="index.php"><img src="img/bank.png" alt="My Bank" style="height : 50px"></a> 
      <a class="navbar-brand" href="index.php">MY BANK</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="customer.php">View all customer</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfermoney.php">Transfer Money</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php">Transaction History</a>
              </li>
          </div>
       </nav>
